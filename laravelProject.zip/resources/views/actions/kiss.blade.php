@extends('layouts.master')
@section('title')
  Kiss
@endsection
@section('content')
<h1>
  I kiss you!
</h1>
<a href = "{{route('homepage')}}">Back to home</a>
@endsection
@extends('layouts.master')

@section('title')
  Nice section
@endsection

@section('content')
<h1>
  I {{$actiontype}} {{$name}}
</h1>
<a href = "{{route('homepage')}}">Back to home</a>
@endsection
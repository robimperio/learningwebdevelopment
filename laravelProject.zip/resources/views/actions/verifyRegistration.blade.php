@extends('layouts.master')

@section('title')
  Validate signup
@endsection

@section('content')

<h1>
  you are a new user
</h1>

@endsection
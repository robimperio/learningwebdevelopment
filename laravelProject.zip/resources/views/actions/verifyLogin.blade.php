@extends('layouts.master')

@section('title')
  Validate login
@endsection

@section('content')
  
<h1>
  Hello {{$yourmail}}. Your password is {{$yourpassword}}. Welcome.
</h1>

@endsection
@extends('layouts.master')
@section('title')
  Greet
@endsection
@section('content')

<h1>
@if ($name != null)
  I greet {{$name}}!
@else
  I greet you!
@endif
</h1>
<a href = "{{route('homepage')}}">Back to home</a>
@endsection
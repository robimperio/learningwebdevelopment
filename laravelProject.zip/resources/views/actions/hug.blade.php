@extends('layouts.master')
@section('title')
  Hug
@endsection
@section('content')
<h1>
  I hug you!
</h1>
<a href = "{{route('homepage')}}">Back to home</a>
@endsection
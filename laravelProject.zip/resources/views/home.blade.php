@extends('layouts.master')

@section('title')
  Learning section
@endsection

@section('content')
    
    <div>
      <a href="{{ route('greet')}}">Greet</a>
      <a href="{{ route('hug') }}">Hug</a>
      <a href="{{ route('kiss') }}">Kiss</a>
    </div>
    <br>
    <br>
    <form action = "{{ route('benice') }}" method = "post">
      @csrf
      <label>I want to...</label>
      <select name="actiontype">
        <option value="greet">Greet</option>
        <option value="hug">Hug</option>
        <option value="kiss">Kiss</option>
      </select>
      <input type = "text" name = "name">
      <button type = 'submit'>Do a nice action</button>
      <input type ="hidden" value ="{{ Session::token() }}" name ="token">
    </form>

    <a href = "{{ route('login') }}">Login</a>
    <br>
    <a href = "{{ route('register') }}">Register</a>
@endsection
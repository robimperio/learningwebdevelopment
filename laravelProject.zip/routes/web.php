<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
})->name('homepage');

Route::get('/greet/{name?}', function ($name = null) {
    return view('actions.greet',['name' => $name]);
})->name('greet');
         
Route::get('/hug', function () {
    return view('actions.hug');
})->name('hug');

Route::get('/kiss', function () {
    return view('actions.kiss');
})->name('kiss');

Route::post('/benice' , function(\Illuminate\HTTP\Request $request){
  if(isset($request['actiontype']) && isset($request['name']))
  {
    if(strlen($request['name']) > 0)
    {
      return view('actions.nice',['actiontype' => $request['actiontype'] , 'name' => $request['name']]);
    }
    return redirect()->back();
  }
  return redirect()->back();
})->name('benice'); 


Route::get('/login', function () {
    return view('actions.signin');
})->name('login');

Route::post('/verifyLogin',[
  'uses' => 'LoginActionController@getLoginVerification', 
  'as' => 'verifyLogin'
  
]); 



/* Route::get('/verifyLogin', function (\Illuminate\HTTP\Request $request) {
    if(isset($request['email']) && isset($request['password']))
    {
      if(strlen($request['email']) && strlen($request['password']))
      {
            return view('actions.verifyLogin', ['yourmail' => $request['email'], 'yourpassword' => $request['password']]);
      }
      return redirect()->back();
    }
    return redirect()->back();
})->name('verifyLogin'); */



Route::get('/signup', function () {
    return view('actions.signup');
})->name('register');

/* Route::post('/checksignup', function () {
    return view('actions.verifyRegistration');
})->name('verifySignIn'); */

Route::group(['middleware' => ['web']] , function()
{

  Route::post('/checksignup', [
    'uses' => 'RegisterController@verifyForm', 
    'as' => 'verifySignIn'
  ]);
}); 
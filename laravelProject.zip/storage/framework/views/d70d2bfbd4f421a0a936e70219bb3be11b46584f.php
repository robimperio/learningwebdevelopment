<?php $__env->startSection('title'); ?>
  Validate login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
<h1>
  Hello <?php echo e($yourmail); ?>. Your password is <?php echo e($yourpassword); ?>. Welcome.
</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
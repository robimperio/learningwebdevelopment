<?php $__env->startSection('title'); ?>
  Greet
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h1>
<?php if($name != null): ?>
  I greet <?php echo e($name); ?>!
<?php else: ?>
  I greet you!
<?php endif; ?>
</h1>
<a href = "<?php echo e(route('homepage')); ?>">Back to home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
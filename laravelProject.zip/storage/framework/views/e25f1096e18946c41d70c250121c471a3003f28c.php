<?php $__env->startSection('title'); ?>
  Sign in
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger" role="alert">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
      </div>
  <?php endif; ?>
  <form action = "<?php echo e(route('verifySignIn')); ?>" method = "post">
    <?php echo csrf_field(); ?>  
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name = "email">
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name = "password">
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" id="exampleRepeatInputPassword1" placeholder="Repeat password" name = "confirmPsw">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
    <input type = "hidden" name = "_token" value = "<?php echo e(Session::token()); ?>]"
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
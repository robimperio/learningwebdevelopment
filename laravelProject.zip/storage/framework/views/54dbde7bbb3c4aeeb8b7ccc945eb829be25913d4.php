<?php $__env->startSection('title'); ?>
  Learning section
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div>
      <a href="<?php echo e(route('greet')); ?>">Greet</a>
      <a href="<?php echo e(route('hug')); ?>">Hug</a>
      <a href="<?php echo e(route('kiss')); ?>">Kiss</a>
    </div>
    <br>
    <br>
    <form action = "<?php echo e(route('benice')); ?>" method = "post">
      <?php echo csrf_field(); ?>
      <label>I want to...</label>
      <select name="actiontype">
        <option value="greet">Greet</option>
        <option value="hug">Hug</option>
        <option value="kiss">Kiss</option>
      </select>
      <input type = "text" name = "name">
      <button type = 'submit'>Do a nice action</button>
      <input type ="hidden" value ="<?php echo e(Session::token()); ?>" name ="token">
    </form>

    <a href = "<?php echo e(route('login')); ?>">Login</a>
    <br>
    <a href = "<?php echo e(route('register')); ?>">Register</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
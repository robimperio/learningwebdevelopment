<?php $__env->startSection('title'); ?>
  Nice section
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>
  I <?php echo e($actiontype); ?> <?php echo e($name); ?>

</h1>
<a href = "<?php echo e(route('homepage')); ?>">Back to home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
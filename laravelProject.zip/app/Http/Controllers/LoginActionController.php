<?php

namespace App\Http\Controllers; 

class LoginActionController extends Controller
{

  public function getLoginVerification(\Illuminate\HTTP\Request $request)
  {
    if(isset($request['email']) && isset($request['password']))
    {
      if(strlen($request['email']) && strlen($request['password']))
      {
            return view('actions.verifyLogin', ['yourmail' => $request['email'], 'yourpassword' => $request['password']]);
      }
      return redirect()->back();
    }
    return redirect()->back();
  }

}
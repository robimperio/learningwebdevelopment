<?php

namespace App\Http\Controllers; 

class RegisterController extends Controller
{
  public function verifyForm(\Illuminate\HTTP\Request $request)
  {
     $this->validate($request,[
      'email' => 'required',
      'password' => 'required',
    ]); 
    return view('actions.verifyRegistration');
  }
}